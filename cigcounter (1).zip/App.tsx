
import React, { useState, useEffect } from 'react';
import { onAuthStateChanged, signInWithPopup, signOut, User } from 'https://www.gstatic.com/firebasejs/10.7.1/firebase-auth.js';
import { doc, getDoc, setDoc, onSnapshot } from 'https://www.gstatic.com/firebasejs/10.7.1/firebase-firestore.js';
import { auth, db, googleProvider } from './services/firebase';
import { UserProfile } from './types';
import Dashboard from './components/Dashboard';
import FriendsList from './components/FriendsList';
import History from './components/History';
import NotificationCenter from './components/NotificationCenter';

const App: React.FC = () => {
  const [user, setUser] = useState<User | null>(null);
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [loading, setLoading] = useState(true);
  const [view, setView] = useState<'dashboard' | 'friends' | 'history'>('dashboard');
  const [loginError, setLoginError] = useState<string | null>(null);
  const [isDemo, setIsDemo] = useState(false);

  useEffect(() => {
    const savedDemo = localStorage.getItem('cigcounter_demo_mode');
    if (savedDemo === 'true') {
      enterDemoMode();
      setLoading(false);
      return;
    }

    const unsubscribe = onAuthStateChanged(auth, async (firebaseUser) => {
      setUser(firebaseUser);
      if (firebaseUser) {
        setLoginError(null);
        setIsDemo(false);
        const userRef = doc(db, 'users', firebaseUser.uid);
        const userSnap = await getDoc(userRef);

        if (!userSnap.exists()) {
          const newProfile: UserProfile = {
            uid: firebaseUser.uid,
            displayName: firebaseUser.displayName,
            photoURL: firebaseUser.photoURL,
            email: firebaseUser.email,
            lastCigTime: null,
            dailyCount: 0,
            friends: [],
          };
          await setDoc(userRef, newProfile);
          setProfile(newProfile);
        } else {
          onSnapshot(userRef, (doc) => {
            setProfile(doc.data() as UserProfile);
          });
        }
      } else {
        setProfile(null);
      }
      setLoading(false);
    });

    return () => unsubscribe();
  }, []);

  const enterDemoMode = () => {
    setIsDemo(true);
    localStorage.setItem('cigcounter_demo_mode', 'true');
    setProfile({
      uid: 'demo-user',
      displayName: 'Demo User',
      photoURL: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Felix',
      email: 'demo@example.com',
      lastCigTime: Date.now() - 3600000 * 2,
      dailyCount: 5,
      friends: ['demo-friend-1']
    });
  };

  const login = async () => {
    setLoginError(null);
    try {
      await signInWithPopup(auth, googleProvider);
    } catch (error: any) {
      console.error("Login failed", error);
      if (error.code === 'auth/unauthorized-domain') {
        setLoginError(`Domain Unauthorized: ${window.location.hostname}`);
      } else {
        setLoginError(error.message || "An unexpected login error occurred.");
      }
    }
  };

  const logout = () => {
    if (isDemo) {
      setIsDemo(false);
      setProfile(null);
      localStorage.removeItem('cigcounter_demo_mode');
    } else {
      signOut(auth);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-900">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-orange-500"></div>
      </div>
    );
  }

  if (!user && !isDemo) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center p-6 bg-slate-900">
        <div className="text-center mb-10">
          <div className="text-6xl mb-4">🚬</div>
          <h1 className="text-4xl font-bold text-white mb-2">CigCounter</h1>
          <p className="text-slate-400">Track your habit, connect with friends, quit together.</p>
        </div>

        <div className="flex flex-col gap-3 w-full max-w-xs">
          <button
            onClick={login}
            className="flex items-center justify-center gap-3 bg-white text-slate-900 px-8 py-4 rounded-full font-bold shadow-xl hover:bg-slate-100 transition-all active:scale-95"
          >
            <img src="https://www.gstatic.com/firebasejs/ui/2.0.0/images/action/google.svg" className="w-6 h-6" alt="Google" />
            Sign in with Google
          </button>
          
          <button
            onClick={enterDemoMode}
            className="text-slate-400 hover:text-white text-sm font-medium py-2 transition-colors"
          >
            Or Try Demo Mode (Local Only)
          </button>
        </div>

        {loginError && (
          <div className="max-w-xs bg-red-900/30 border border-red-500/50 p-4 rounded-2xl text-red-200 text-sm animate-in fade-in zoom-in duration-300 mt-8">
            <div className="font-bold flex items-center gap-2 mb-2 text-red-400">
              <i className="fa-solid fa-circle-exclamation"></i>
              Authorization Required
            </div>
            <p className="mb-3">This domain (e.g. your GitHub Pages URL) isn't allowed to log in yet.</p>
            <div className="bg-black/40 p-2 rounded font-mono text-[10px] break-all mb-3 select-all cursor-pointer hover:bg-black/60 transition-colors flex justify-between items-center" onClick={() => {
              navigator.clipboard.writeText(window.location.hostname);
              alert('Domain copied!');
            }}>
              <span>{window.location.hostname}</span>
              <i className="fa-solid fa-copy ml-1 opacity-50"></i>
            </div>
            <ol className="list-decimal list-inside space-y-1 text-[11px] opacity-80">
              <li>Open <a href="https://console.firebase.google.com/" target="_blank" className="underline font-bold text-red-300">Firebase Console</a></li>
              <li>Authentication > Settings > Authorized Domains</li>
              <li>Add the domain copied above</li>
            </ol>
          </div>
        )}
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-900 text-white pb-24">
      {!isDemo && <NotificationCenter profile={profile} />}
      
      <header className="p-4 flex justify-between items-center border-b border-slate-800 sticky top-0 bg-slate-900/80 backdrop-blur-md z-40">
        <div className="flex items-center gap-2">
          <span className="text-2xl font-bold bg-gradient-to-r from-orange-400 to-red-600 bg-clip-text text-transparent">CigCounter</span>
          {isDemo && <span className="bg-blue-500/20 text-blue-400 text-[10px] px-2 py-0.5 rounded-full font-bold border border-blue-500/30 uppercase">Demo</span>}
        </div>
        <button onClick={logout} className="text-slate-400 hover:text-white transition-colors p-2">
          <i className="fa-solid fa-right-from-bracket"></i>
        </button>
      </header>

      <main className="max-w-md mx-auto p-4 view-enter">
        {view === 'dashboard' && profile && (
          <Dashboard 
            profile={profile} 
            isDemo={isDemo} 
            onUpdateProfile={(newProfile) => setProfile(prev => prev ? ({...prev, ...newProfile}) : null)} 
          />
        )}
        {view === 'friends' && profile && <FriendsList profile={profile} isDemo={isDemo} />}
        {view === 'history' && profile && <History profile={profile} isDemo={isDemo} />}
      </main>

      <nav className="fixed bottom-0 left-0 right-0 bg-slate-800/90 backdrop-blur-lg border-t border-slate-700 flex justify-around items-center p-4 z-50">
        <button 
          onClick={() => setView('dashboard')}
          className={`flex flex-col items-center gap-1 transition-colors ${view === 'dashboard' ? 'text-orange-500' : 'text-slate-400'}`}
        >
          <i className="fa-solid fa-house text-xl"></i>
          <span className="text-xs">Home</span>
        </button>
        <button 
          onClick={() => setView('history')}
          className={`flex flex-col items-center gap-1 transition-colors ${view === 'history' ? 'text-orange-500' : 'text-slate-400'}`}
        >
          <i className="fa-solid fa-calendar-days text-xl"></i>
          <span className="text-xs">History</span>
        </button>
        <button 
          onClick={() => setView('friends')}
          className={`flex flex-col items-center gap-1 transition-colors ${view === 'friends' ? 'text-orange-500' : 'text-slate-400'}`}
        >
          <i className="fa-solid fa-users text-xl"></i>
          <span className="text-xs">Friends</span>
        </button>
      </nav>
    </div>
  );
};

export default App;
