
# CigCounter Deployment Guide

Follow these steps to deploy your app to GitHub Pages.

## 1. Upload to GitHub
1. Create a new repository on GitHub.
2. Push all the files in this project to the `main` branch of your new repository.

## 2. Enable GitHub Pages
You have two easy ways to do this:

### Option A: Direct from Main (Easiest)
1. Go to your repository on GitHub.com.
2. Click **Settings** (top bar).
3. Click **Pages** (left sidebar).
4. Under **Build and deployment > Source**, ensure "Deploy from a branch" is selected.
5. Under **Branch**, select `main` and folder `/ (root)`.
6. Click **Save**.

### Option B: The "gh-pages" Branch (Automatic)
If you want to use a separate branch like "gh-pages":
1. I have included a GitHub Action in `.github/workflows/deploy.yml`. 
2. Once you push your code to `main`, GitHub will automatically create/update a `gh-pages` branch for you and deploy it.
3. You just need to go to **Settings > Pages** and ensure the source is set to "GitHub Actions".

## 3. Authorize the Domain in Firebase (MANDATORY)
The app will show "Unauthorized Domain" until you do this:
1. Open your [Firebase Console](https://console.firebase.google.com/).
2. Select your project: `cigcounter-6a722`.
3. Go to **Build > Authentication** > **Settings** tab.
4. Click **Authorized Domains** in the left menu.
5. Click **Add Domain**.
6. Enter your GitHub URL: `YOUR_USERNAME.github.io`. (Do not include "https://" or the repository name).

## 4. Install as a "SIM" (Standalone App)
1. Open your site on your phone's browser.
2. **iOS (Safari):** Tap "Share" -> "Add to Home Screen".
3. **Android (Chrome):** Tap three dots -> "Install app".
4. The app will now appear on your home screen with its own icon and no browser bars!
